package com.iverson.productmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductManagementAppUsingRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
