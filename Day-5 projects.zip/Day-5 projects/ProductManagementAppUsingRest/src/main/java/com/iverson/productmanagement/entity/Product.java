package com.iverson.productmanagement.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

@Entity
@Table(name="products_info")
public class Product {
	@Id	
	@Min(value=100,message="Product Id can't be less than 100")
	@Max(value=2000,message="product Id can't be greater than 2000")
	private int productId;
	@NotEmpty(message="product name is mandatory")
	private String productName;
	@Min(value=1000,message="Product price can't be less than 1000")
	private int productPrice;
	private String productCategory;

	public Product() {
		System.out.println("default constructor");
	}

	@Override
	public String toString() {
		return "productId=" + productId + ", productName=" + productName + ", productPrice=" + productPrice
				+ ", productCategory=" + productCategory + "";
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public String getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}

	public Product(int productId, String productName, int productPrice, String productCategory) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productPrice = productPrice;
		this.productCategory = productCategory;
	}

}
