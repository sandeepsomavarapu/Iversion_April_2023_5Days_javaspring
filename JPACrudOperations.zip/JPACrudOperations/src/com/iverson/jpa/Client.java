package com.iverson.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("jpa");

		EntityManager entityManager = factory.createEntityManager();
		entityManager.getTransaction().begin();
		Employee emp=entityManager.find(Employee.class, 111);
		
		System.out.println(emp);
		
			entityManager.remove(emp);
		
//			emp.setEmpSal(50000);
//			emp.setEmpName("naresh");
//			entityManager.merge(emp);
	
//		Employee emp=new Employee(112,"suresh",90000,"developer");		
//		entityManager.persist(emp);
	
		
		
		entityManager.getTransaction().commit();
		
	}

}
