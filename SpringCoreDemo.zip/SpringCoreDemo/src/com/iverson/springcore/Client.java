package com.iverson.springcore;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {

//		Resource resource = new ClassPathResource("springconfig.xml");// loading the config file
//		BeanFactory factory = new XmlBeanFactory(resource);// providing config file to container  LAZY initializer

		
		ApplicationContext context=new ClassPathXmlApplicationContext("springconfig.xml"); //eager initializer 
		Employee emp = (Employee) context.getBean("emp");

		
		
		
		System.out.println(emp);// object address
		
		
		//setter injection		--><property>
		//constructor injection --><constructor-arg>
		
	}

}
